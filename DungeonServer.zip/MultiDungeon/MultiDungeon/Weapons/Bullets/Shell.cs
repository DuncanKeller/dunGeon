﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultiDungeon
{
    class Shell : Bullet
    {
        
        public Shell() : base()
        {
            speed = 700;
        }
    }
}
