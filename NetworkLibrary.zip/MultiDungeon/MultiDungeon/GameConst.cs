﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultiDungeon
{
    static class GameConst
    {
        public static int SCREEN_WIDTH = 800;
        public static int SCREEN_HEIGHT = 800;
        public static Random rand = new Random();
    }
}