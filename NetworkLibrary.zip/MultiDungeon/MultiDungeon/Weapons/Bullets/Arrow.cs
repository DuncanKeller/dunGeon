﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultiDungeon
{
    class Arrow : Bullet
    {

        public Arrow()
            : base()
        {
            speed = 850;
        }
    }
}
